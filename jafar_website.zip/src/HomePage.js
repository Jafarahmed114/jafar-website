export default function HomePage() {
  return (
    <main className="min-h-screen bg-gray-50 p-6">
      <header className="text-center mb-12">
        <h1 className="text-5xl font-bold text-yellow-600">Jafar Ahmed</h1>
        <p className="text-xl text-gray-600 mt-4">
          Senior Consultant in DRM, PFM, Governance, Tax Administration, Trade, and Climate Finance
        </p>
        <p className="text-md text-gray-500 mt-2 italic">With specialized expertise in fragile and conflict-affected settings</p>
      </header>

      <section className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold text-yellow-700 mb-4">About Jafar</h2>
          <p className="text-gray-700 text-md">
            Jafar Ahmed is a highly experienced and results-driven senior consultant with over 12 years of international
            experience in public financial management (PFM), domestic revenue mobilization (DRM), tax policy and
            administration, climate finance, and trade policy. He has led reform efforts and advisory missions across
            fragile and post-conflict countries, including Somalia and South Sudan. Jafar has advised governments,
            development partners, and international financial institutions on strategy, policy design, and institutional
            capacity building.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold text-yellow-700 mb-4">Expertise</h2>
          <ul className="list-disc list-inside text-gray-700">
            <li>Domestic Revenue Mobilization (DRM) Strategy</li>
            <li>Public Financial Management (PFM) Reform</li>
            <li>Governance and Anti-Corruption Frameworks</li>
            <li>Tax Administration and Compliance Systems</li>
            <li>Customs Modernization and Trade Facilitation</li>
            <li>Climate Finance Readiness and Project Design</li>
            <li>Fragile State Institutional Capacity Building</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-md col-span-1 md:col-span-2">
          <h2 className="text-2xl font-semibold text-yellow-700 mb-4">Recent Engagements</h2>
          <ul className="text-gray-700 space-y-2">
            <li>
              <strong>AfDB – Principal, South Sudan Revenue Academy:</strong> Led establishment and curriculum design of a
              national revenue training institution.
            </li>
            <li>
              <strong>IMF/World Bank – Technical Advisor:</strong> Supported DRM and MTRS design in post-conflict Somalia.
            </li>
            <li>
              <strong>Somali Ministry of Finance – Director General of Revenue:</strong> Spearheaded tax modernization,
              ITAS implementation, and federal revenue-sharing negotiations.
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold text-yellow-700 mb-4">Contact</h2>
          <p className="text-gray-700 mb-2">Email: <a href="mailto:jafar@jafarahmed.com" className="text-yellow-700 underline">jafar@jafarahmed.com</a></p>
          <p className="text-gray-700">LinkedIn: <a href="#" className="text-yellow-700 underline">linkedin.com/in/jafarahmed</a></p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-md">
          <h2 className="text-2xl font-semibold text-yellow-700 mb-4">Download Profile</h2>
          <a
            href="/Jafar_Ahmed_Consultant_Profile.pdf"
            className="inline-block mt-4 bg-yellow-600 text-white py-2 px-4 rounded-xl shadow hover:bg-yellow-700"
          >
            Consultant Profile (PDF)
          </a>
        </div>
      </section>

      <footer className="mt-20 text-center text-gray-400 text-sm">
        © {new Date().getFullYear()} Jafar Ahmed. All rights reserved.
      </footer>
    </main>
  );
}
